import re

# Simple translation dictionary for demonstration purposes
TRANSLATIONS = {
    'English': {
        'greeting': 'Hello. I am your SIRI BANK AI Assistant. How can I help you today?',
        'balance_inquiry': 'Your current account balance for account {} is {} rupees.',
        'request_card_success': 'Your request for a new ATM Card has been successfully submitted.',
        'request_aadhaar_success': 'Your request to link Aadhaar has been submitted and is pending verification.',
        'usage_guidance': "Here is how to use SIRI BANK safely. First. Use the Sliding Toggle in ATM Services to switch between cards. Second. Complete your Aadhaar KYC to unlock Platinum Credit Card offers. Third. Check your Transaction History regularly. Fourth. Use the Chatbot's Voice Search for easy navigation. Remember. Never share your ATM PIN or OTP with anyone. Do not log in from public computers.",
        'not_understood': 'I did not understand that. Could you please rephrase? You can ask me about your balance, how to use the site, or getting a new card.',
        'please_wait': 'Processing your request...'
    },
    'Hindi': {
        'greeting': 'नमस्ते! मैं आपका SIRI BANK AI सहायक हूँ। आज मैं आपकी कैसे मदद कर सकता हूँ?',
        'balance_inquiry': 'खाता {} के लिए आपका वर्तमान बैलेंस ₹{} है।',
        'request_card_success': 'नए ATM कार्ड के लिए आपका अनुरोध सफलतापूर्वक सबमिट कर दिया गया है।',
        'request_aadhaar_success': 'आधार लिंक करने का आपका अनुरोध सबमिट कर दिया गया है और सत्यापन के लिए लंबित है।',
        'usage_guidance': "यहाँ SIRI BANK का सुरक्षित उपयोग करने का तरीका बताया गया है:\n\n✅ क्या करें:\n1. डेबिट/क्रेडिट कार्ड के बीच स्विच करने के लिए ATM सेवाओं में स्लाइडिंग टॉगल का उपयोग करें।\n2. प्लैटिनम क्रेडिट कार्ड ऑफ़र अनलॉक करने के लिए अपना आधार केवाईसी पूरा करें।\n3. नियमित रूप से अपने लेनदेन इतिहास की जांच करें।\n4. हैंड्स-फ्री नेविगेशन के लिए चैटबॉट के वॉयस सर्च का उपयोग करें।\n\n❌ क्या न करें:\n1. अपना एटीएम पिन या ओटीपी कभी किसी के साथ साझा न करें।\n2. सार्वजनिक कंप्यूटर या असुरक्षित वाई-फाई से लॉग इन न करें।\n3. 'कार्ड ब्लॉक' सूचनाओं को अनदेखा न करें।",
        'not_understood': 'मुझे समझ नहीं आया। कृपया फिर से कहें? आप मुझसे अपने बैलेंस, साइट का उपयोग कैसे करें, या कार्ड के बारे में पूछ सकते हैं।',
        'please_wait': 'आपके अनुरोध पर कार्रवाई की जा रही है...'
    },
    'Kannada': {
        'greeting': 'ನಮಸ್ಕಾರ! ನಾನು ನಿಮ್ಮ SIRI BANK AI ಸಹಾಯಕ. ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಲ್ಲೆ?',
        'balance_inquiry': 'ಖಾತೆ {} ಗಾಗಿ ನಿಮ್ಮ ಪ್ರಸ್ತುತ ಬ್ಯಾಲೆನ್ಸ್ ₹{}.',
        'request_card_success': 'ಹೊಸ ATM ಕಾರ್ಡ್‌ಗಾಗಿ ನಿಮ್ಮ ವಿನಂತಿಯನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಸಲ್ಲಿಸಲಾಗಿದೆ.',
        'request_aadhaar_success': 'ಆಧಾರ್ ಲಿಂಕ್ ಮಾಡುವ ನಿಮ್ಮ ವಿನಂತಿಯನ್ನು ಸಲ್ಲಿಸಲಾಗಿದೆ ಮತ್ತು ಪರಿಶೀಲನೆ ಬಾಕಿಯಿದೆ.',
        'usage_guidance': "ಸಿರಿ ಬ್ಯಾಂಕ್ ಅನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಬಳಸುವ ವಿಧಾನ ಇಲ್ಲಿದೆ:\n\n✅ ಮಾಡಬೇಕಾದುದು:\n1. ಡೆಬಿಟ್/ಕ್ರೆಡಿಟ್ ಕಾರ್ಡ್‌ಗಳ ನಡುವೆ ಬದಲಾಯಿಸಲು ಎಟಿಎಂ ಸೇವೆಗಳಲ್ಲಿ ಸ್ಲೈಡಿಂಗ್ ಟಾಗಲ್ ಬಳಸಿ.\n2. ಪ್ಲಾಟಿನಂ ಕ್ರೆಡಿಟ್ ಕಾರ್ಡ್ ಆಫರ್‌ಗಳನ್ನು ಅನ್‌ಲಾಕ್ ಮಾಡಲು ನಿಮ್ಮ ಆಧಾರ್ ಕೆವೈಸಿ ಪೂರ್ಣಗೊಳಿಸಿ.\n3. ನಿಮ್ಮ ವಹಿವಾಟಿನ ಇತಿಹಾಸವನ್ನು ನಿಯಮಿತವಾಗಿ ಪರಿಶೀಲಿಸಿ.\n4. ಹ್ಯಾಂಡ್ಸ್-ಫ್ರೀ ನ್ಯಾವಿಗೇಶನ್ಗಾಗಿ ಚಾಟ್‌ಬಾಟ್‌ನ ಧ್ವನಿ ಹುಡುಕಾಟವನ್ನು ಬಳಸಿ.\n\n❌ ಮಾಡಬಾರದು:\n1. ನಿಮ್ಮ ಎಟಿಎಂ ಪಿನ್ ಅಥವಾ ಒಟಿಪಿಯನ್ನು ಯಾರೊಂದಿಗೂ ಹಂಚಿಕೊಳ್ಳಬೇಡಿ.\n2. ಸಾರ್ವಜನಿಕ ಕಂಪ್ಯೂಟರ್‌ಗಳು ಅಥವಾ ಅಸುರಕ್ಷಿತ ವೈ-ಫೈನಿಂದ ಲಾಗಿನ್ ಮಾಡಬೇಡಿ.\n3. 'ಕಾರ್ಡ್ ಬ್ಲಾಕ್' ಅಧಿಸೂಚನೆಗಳನ್ನು ನಿರ್ಲಕ್ಷಿಸಬೇಡಿ.",
        'not_understood': 'ನನಗೆ ಅರ್ಥವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಮತ್ತೊಮ್ಮೆ ಹೇಳಬಹುದೇ? ನಿಮ್ಮ ಬ್ಯಾಲೆನ್ಸ್, ಸೈಟ್ ಬಳಕೆ ಅಥವಾ ಹೊಸ ಕಾರ್ಡ್ ಬಗ್ಗೆ ನೀವು ನನ್ನನ್ನು ಕೇಳಬಹುದು.',
        'please_wait': 'ನಿಮ್ಮ ವಿನಂತಿಯನ್ನು ಪ್ರಕ್ರಿಯೆಗೊಳಿಸಲಾಗುತ್ತಿದೆ...'
    }
}

def get_translation(lang, key):
    if lang not in TRANSLATIONS:
        lang = 'English'
    return TRANSLATIONS[lang].get(key, TRANSLATIONS['English'].get(key, ''))

def process_chat_intent(text, user_state, language="English"):
    text_lower = text.lower()
    
    # 0. Usage Guidance (Help)
    if re.search(r'\b(help|usage|how to|guide|tips|what to do|don\'ts|help|मदद|ಸಹಾಯ)\b', text_lower):
        return {
            'intent': 'USAGE_GUIDANCE',
            'reply': get_translation(language, 'usage_guidance'),
            'action': None
        }

    # 1. Balance Inquiry
    if re.search(r'\b(balance|money|funds|amount|बैलेंस|ಬ್ಯಾಲೆನ್ಸ್)\b', text_lower):
        acc_num = user_state.get('account_number', 'N/A')
        balance = user_state.get('balance', '0.00')
        return {
            'intent': 'BALANCE_INQUIRY',
            'reply': get_translation(language, 'balance_inquiry').format(acc_num, balance),
            'action': None
        }

    # 2. ATM Card Request
    if re.search(r'\b(atm|card|debit|credit|एटीएम|ಎಟಿಎಂ)\b', text_lower):
        return {
            'intent': 'ATM_CARD_REQUEST',
            'reply': get_translation(language, 'request_card_success'),
            'action': 'CREATE_REQUEST_ATM'
        }

    # 3. Aadhaar Link
    if re.search(r'\b(aadhaar|aadhar|kyc|link|आधार|ಆಧಾರ್)\b', text_lower):
        return {
            'intent': 'AADHAAR_LINK_REQUEST',
            'reply': get_translation(language, 'request_aadhaar_success'),
            'action': 'CREATE_REQUEST_AADHAAR'
        }
        
    # 4. Greeting
    if re.search(r'\b(hi|hello|hey|namaste|नमस्ते|ನಮಸ್ಕಾರ)\b', text_lower):
        return {
            'intent': 'GREETING',
            'reply': get_translation(language, 'greeting'),
            'action': None
        }

    # Default fallback
    return {
        'intent': 'UNKNOWN',
        'reply': get_translation(language, 'not_understood'),
        'action': None
    }
