from flask import Flask, request, jsonify, render_template, session, redirect, url_for, Response
from db_utils import authenticate_user, get_user_account_summary, create_bank_request
from chatbot_logic import process_chat_intent, get_translation
import os, csv, io

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'super_secret_siri_bank_key')

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('home'))
    return render_template('login.html')

@app.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    # Simulate credit card eligibility: Only CUST1001 gets it for demo
    has_credit_card = (session.get('customer_id') == 'CUST1001')
    return render_template('index.html', 
                          user_name=session.get('user_name'),
                          language=session.get('language', 'English'),
                          has_credit_card=has_credit_card)

@app.route('/pay')
def pay():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    return render_template('pay.html', 
                          user_name=session.get('user_name'),
                          language=session.get('language', 'English'))

@app.route('/atm-services')
def atm_services():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    # Simulate credit card eligibility: Only CUST1001 gets it for demo
    has_credit_card = (session.get('customer_id') == 'CUST1001')
    return render_template('atm.html', 
                          user_name=session.get('user_name'),
                          language=session.get('language', 'English'),
                          has_credit_card=has_credit_card)

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json
    identifier = data.get('identifier')
    password = data.get('password')
    
    if not identifier or not password:
        return jsonify({"success": False, "message": "Missing credentials"})
    
    user, msg = authenticate_user(identifier, password)
    if user:
        session['user_id'] = user['id']
        session['user_name'] = user['full_name']
        session['language'] = user['preferred_language']
        session['customer_id'] = user['customer_id']
        session['is_admin'] = user['is_admin']
        
        redirect_url = '/admin' if user['is_admin'] else '/home'
        return jsonify({"success": True, "message": "Logged in successfully", "redirect": redirect_url})
    else:
        return jsonify({"success": False, "message": msg}), 401

@app.route('/aadhaar-kyc')
def kyc():
    if 'user_id' not in session or session.get('is_admin'):
        return redirect(url_for('index'))
    
    summary = get_user_account_summary(session['user_id'])
    kyc_status = None
    if summary and 'recent_requests' in summary:
        for req in summary['recent_requests']:
            if req['request_type'] == 'AADHAAR_LINK':
                kyc_status = req['status']
                break

    return render_template('kyc.html', 
                          user_name=session.get('user_name'), 
                          language=session.get('language'),
                          kyc_status=kyc_status)

@app.route('/request-history')
def history():
    if 'user_id' not in session or session.get('is_admin'):
        return redirect(url_for('index'))
    return render_template('history.html', user_name=session.get('user_name'), language=session.get('language'))

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    return render_template('profile.html', 
                          user_name=session.get('user_name'),
                          language=session.get('language', 'English'))

from db_utils import get_all_users_and_requests, update_request_status, execute_transfer, create_new_user, admin_execute_financial_op, get_system_analytics, apply_for_loan, get_all_loans, admin_process_loan, save_standing_instruction, execute_all_standing_instructions, get_standing_instructions, get_suggested_payees, get_user_by_phone

@app.route('/admin')
def admin():
    if not session.get('is_admin'):
        return redirect(url_for('index'))
    data = get_all_users_and_requests()
    data['loans'] = get_all_loans()
    return render_template('admin.html', user_name=session.get('user_name'), data=data)

@app.route('/api/admin/update_request', methods=['POST'])
def admin_update_request():
    if not session.get('is_admin'):
        return jsonify({"error": "Unauthorized"}), 401
    data = request.json
    success = update_request_status(data.get('request_id'), data.get('status'))
    return jsonify({"success": success})

@app.route('/api/admin/analytics', methods=['GET'])
def admin_analytics():
    if not session.get('is_admin'):
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_system_analytics())

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.json or {}
    full_name = data.get('full_name')
    phone_number = data.get('phone_number')
    password = data.get('password')
    initial_deposit = data.get('initial_deposit', 5000)
    preferred_language = data.get('preferred_language', 'English')
    
    if not full_name or not phone_number or not password:
        return jsonify({"success": False, "message": "Full Name, Mobile Number, and Password are required."}), 400
        
    try:
        deposit_val = float(initial_deposit)
        if deposit_val < 0:
            deposit_val = 0
    except ValueError:
        deposit_val = 5000.0
        
    success, result = create_new_user(
        full_name=full_name,
        phone=phone_number,
        password=password,
        initial_deposit=deposit_val,
        preferred_language=preferred_language
    )
    
    if success:
        # Auto log in the newly registered user
        session['user_id'] = result['user_id']
        session['user_name'] = result['full_name']
        session['language'] = result['preferred_language']
        session['customer_id'] = result['customer_id']
        session['is_admin'] = 0
        
        return jsonify({
            "success": True,
            "message": "Account created successfully!",
            "user": result,
            "redirect": "/home"
        })
    else:
        return jsonify({"success": False, "message": result}), 400

@app.route('/api/admin/create_user', methods=['POST'])
def admin_create_user():
    if not session.get('is_admin'):
        return jsonify({"error": "Unauthorized"}), 401
    data = request.json or {}
    success, result = create_new_user(
        full_name=data.get('full_name'),
        phone=data.get('phone_number'),
        password=data.get('password', 'password123'),
        initial_deposit=float(data.get('initial_deposit', 0))
    )
    if success:
        msg = f"Account {result['account_number']} created successfully for {result['full_name']}"
        return jsonify({"success": True, "message": msg})
    else:
        return jsonify({"success": False, "message": result})

@app.route('/api/admin/transaction', methods=['POST'])
def admin_transaction():
    if not session.get('is_admin'):
        return jsonify({"error": "Unauthorized"}), 401
    data = request.json
    success, result = admin_execute_financial_op(
        data.get('account_number'),
        data.get('ifsc_code', 'UNKNOWN'),
        data.get('op_type'),
        float(data.get('amount', 0)),
        data.get('narration', '')
    )
    if success:
        return jsonify({"success": True, "message": result['msg'], "txn_id": result['txn_id'], "balance": result['balance']})
    else:
        return jsonify({"success": False, "message": result})

@app.route('/api/transfer', methods=['POST'])
def api_transfer():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    data = request.json
    success, msg = execute_transfer(session['user_id'], data.get('receiver_account'), float(data.get('amount')))
    return jsonify({"success": success, "message": msg})

@app.route('/api/transfer/phone', methods=['POST'])
def api_transfer_phone():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    data = request.json
    phone = data.get('phone_number')
    amount = data.get('amount')
    
    if not phone or not amount:
        return jsonify({"success": False, "message": "Missing phone number or amount"})
        
    user_info = get_user_by_phone(phone)
    if not user_info:
        return jsonify({"success": False, "message": "Phone number not registered with SIRI BANK"})
        
    success, msg = execute_transfer(session['user_id'], user_info['account_number'], float(amount))
    return jsonify({"success": success, "message": msg, "receiver_name": user_info['full_name']})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({"success": True})

@app.route('/api/user/summary', methods=['GET'])
def api_user_summary():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    
    summary = get_user_account_summary(session['user_id'])
    if summary:
        return jsonify(summary)
    return jsonify({"error": "Failed to load summary"}), 500

@app.route('/api/user/upcoming', methods=['GET'])
def api_user_upcoming():
    if 'user_id' not in session: return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_standing_instructions(session['user_id']))

@app.route('/api/user/payees', methods=['GET'])
def api_user_payees():
    if 'user_id' not in session: return jsonify({"error": "Unauthorized"}), 401
    return jsonify(get_suggested_payees(session['user_id']))

@app.route('/api/user/statement/download', methods=['GET'])
def api_download_statement():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    
    summary = get_user_account_summary(session['user_id'])
    if not summary or 'transactions' not in summary:
        return "Failed to load ledger", 500
        
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['Transaction ID', 'Date', 'Type', 'Description', 'Amount', 'Sender', 'Receiver'])
    
    for tx in summary['transactions']:
        cw.writerow([
            f"TXN-{tx['id']}",
            tx['created_at'],
            tx['transaction_type'],
            tx['description'],
            tx['amount'],
            tx['sender_name'] if tx['sender_name'] else 'SYSTEM',
            tx['receiver_name'] if tx['receiver_name'] else 'SYSTEM'
        ])
        
    output = si.getvalue()
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=account_statement.csv"}
    )

@app.route('/api/user/kyc/submit', methods=['POST'])
def api_submit_kyc():
    if 'user_id' not in session: return jsonify({"error": "Unauthorized"}), 401
    d = request.json
    rtype = d.get('request_type', 'AADHAAR_LINK')
    details = d.get('details', 'Completed Aadhaar KYC via multi-step wizard')
    create_bank_request(session['user_id'], rtype, details)
    return jsonify({"success": True, "message": "Request Submitted Successfully"})

@app.route('/api/user/loan', methods=['POST'])
def api_user_loan():
    if 'user_id' not in session: return jsonify({"error": "Unauthorized"}), 401
    d = request.json
    success, msg = apply_for_loan(session['user_id'], float(d.get('amount')), d.get('purpose'))
    return jsonify({"success": success, "message": msg})

@app.route('/api/admin/loan_action', methods=['POST'])
def api_admin_loan_action():
    if not session.get('is_admin'): return jsonify({"error": "Unauthorized"}), 401
    d = request.json
    success, msg = admin_process_loan(d.get('loan_id'), d.get('action'))
    return jsonify({"success": success, "message": msg})

@app.route('/api/standing_instruction', methods=['POST'])
def api_standing_instruction():
    if 'user_id' not in session: return jsonify({"error": "Unauthorized"}), 401
    d = request.json
    success, msg = save_standing_instruction(session['user_id'], d.get('receiver_account'), d.get('amount'), d.get('day_of_month', 1))
    return jsonify({"success": success, "message": msg})

@app.route('/api/admin/run_cron', methods=['POST'])
def api_admin_run_cron():
    if not session.get('is_admin'): return jsonify({"error": "Unauthorized"}), 401
    executed, msg = execute_all_standing_instructions()
    return jsonify({"success": True, "message": msg, "count": executed})

@app.route('/api/chat', methods=['POST'])
def api_chat():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
        
    data = request.json
    user_message = data.get('message', '')
    language = data.get('language', session.get('language', 'English'))
    
    # Save the selected language back to session if changed
    if language != session.get('language'):
        session['language'] = language
        
    # Get user context for the bot (e.g. balance)
    summary = get_user_account_summary(session['user_id'])
    user_state = {}
    if summary and summary.get("accounts"):
        acc = summary["accounts"][0]
        user_state['account_number'] = acc['account_number']
        user_state['balance'] = str(acc['balance'])
        
    # Process intent
    response_data = process_chat_intent(user_message, user_state, language=language)
    
    # Handle DB actions based on intent
    if response_data.get('action') == 'CREATE_REQUEST_ATM':
        create_bank_request(session['user_id'], 'ATM_CARD', 'Requested Visa Debit Card via Assistant')
    elif response_data.get('action') == 'CREATE_REQUEST_AADHAAR':
        create_bank_request(session['user_id'], 'AADHAAR_LINK', 'Requested Aadhaar Linking via Assistant')
        
    return jsonify({
        "reply": response_data['reply'],
        "intent": response_data['intent']
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
