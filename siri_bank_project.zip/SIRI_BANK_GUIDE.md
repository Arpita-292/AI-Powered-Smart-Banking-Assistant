# SIRI BANK: Smart AI-Powered Banking System
### Comprehensive Product & Architecture Guide for Students

SIRI BANK is a prototype web application demonstrating a modern, responsive, and interactive digital banking experience. It combines a client-side portal, a secure admin-side back-office, a database ledger system, and an interactive AI chatbot assistant featuring voice commands and multi-lingual support.

---

## 1. System Architecture & Tech Stack

SIRI BANK is designed around a lightweight, high-performance architecture:

```mermaid
graph TD
    User([Customer / Admin Browser]) -->|HTTP Requests / JSON API| Flask[Flask Web Server (Python)]
    Flask -->|SQL Queries| DB[(SQLite Database: siri_bank.db)]
    Flask -->|Renders Templates| HTML[HTML5 / CSS3 / Vanilla JS]
    User -->|Voice Commands| WebSpeech[Web Speech API (Browser)]
    User -->|Charts & Graphs| ChartJS[Chart.js (Admin Analytics)]
```

### Core Technologies Used
1. **Frontend (User Interface):**
   - **HTML5 & Vanilla CSS3:** Styled with custom color palettes (Indigo, Slate, and Emerald) and interactive micro-animations (e.g., hover transforms, sliding widgets).
   - **JavaScript (ES6):** Handles client-side API requests, UI state management, simulated hardware interactions (OTP entry, Face Scan, Fingerprint Scan), and chatbot logic.
   - **Chart.js:** Utilized in the Admin Panel for interactive visual reports.
   - **FontAwesome & Google Fonts (Inter):** For sleek iconography and modern typography.
   - **Web Speech API:** Powering the voice recognition capability of the chatbot assistant.

2. **Backend (Application Logic):**
   - **Python (Flask):** Serves routes, manages sessions (login state, preferred language), and handles JSON endpoints for financial transactions.
   - **Gunicorn:** Configured as the production WSGI HTTP server (defined in `Procfile` for cloud deployment).

3. **Database (Ledger System):**
   - **SQLite (`siri_bank.db`):** An embedded relational database that holds information about accounts, users, requests, ledger entries (transactions), loans, and standing instructions.

---

## 2. Database Schema & Data Model

SIRI BANK uses a relational model to manage accounts, security credentials, request logs, and financial transactions. 

### Entity-Relationship Diagram (ERD)

```mermaid
erDiagram
    USERS ||--o| ACCOUNTS : "has one"
    USERS ||--o{ TRANSACTIONS : "sender / receiver"
    USERS ||--o{ REQUESTS : "makes"
    USERS ||--o{ LOANS : "applies for"
    USERS ||--o{ STANDING_INSTRUCTIONS : "schedules"

    USERS {
        int id PK
        string customer_id UK
        string phone_number UK
        string password_hash
        string full_name
        string preferred_language
        string upi_id UK
        boolean is_admin
        timestamp created_at
    }

    ACCOUNTS {
        int id PK
        int user_id FK
        string account_number UK
        decimal balance
        string status
    }

    TRANSACTIONS {
        int id PK
        int sender_id FK
        int receiver_id FK
        decimal amount
        string transaction_type
        string description
        timestamp created_at
    }

    REQUESTS {
        int id PK
        int user_id FK
        string request_type
        text request_details
        string status
        timestamp created_at
    }

    LOANS {
        int id PK
        int user_id FK
        decimal amount
        text purpose
        string status
        timestamp created_at
    }

    STANDING_INSTRUCTIONS {
        int id PK
        int user_id FK
        string receiver_account
        decimal amount
        int day_of_month
        timestamp last_executed
        timestamp created_at
    }
```

### Table Definitions & Roles

* **`users`:** Stores core customer attributes, login configurations, preferred language, UPI identities, and the administrative flag (`is_admin`).
* **`accounts`:** Holds bank account balances, statuses (`ACTIVE` or `INACTIVE`), and links back to the user profiles.
* **`transactions`:** The central ledger capturing all money movements (Deposits, Withdrawals, and Peer-to-Peer Transfers).
* **`requests`:** An operations queue where users request services (like ATM Debit Cards or Aadhaar KYC links) for admins to review.
* **`loans`:** Manages debt requests, capturing loan amounts, user purposes, and underwriting statuses.
* **`standing_instructions`:** Stores automated, recurring monthly payment instructions (autopay).

---

## 3. Customer Portal walkthrough & User Flows

The Customer Portal provides a clean dashboard mimicking a real online banking app. Below is a detailed walkthrough of each module and how users interact with it.

### A. Login & Simulated Authentication
* **Location:** `/` (Login Page)
* **How it works:**
  - Standard login accepts either a **Phone Number** or **Customer ID** along with a password.
  - **Simulated Fingerprint Auth:** Clicking this button runs a 1-second scan simulation, auto-fills credentials for the demo customer, and logs them in instantly.
* **Demo Credentials:**
  - **Customer Login:** `CUST1001` / `password123` (Arpitha)
  - **Admin Login:** `ADMIN001` / `admin123` (System Administrator)

---

### B. Interactive Home Dashboard
* **Location:** `/home`
* **Features:**
  1. **Savings Balance Card (Slider):**
     - Shows the account balance, UPI ID, and account number.
     - **Privacy Eye Toggle:** Users can click the eye icon to hide/blur sensitive account parameters (`₹1,55,000` blurred out).
     - **Card Slider:** Dragging or clicking the slider dots navigates between the **SIRI Savings Account** and the **SIRI Platinum Credit Card** card views.
  2. **Credit Eligibility:**
     - Only verified customers (like `CUST1001` in the database seed) see the **Platinum Credit Card** detail (Limit: `₹5,00,000`). Other users see a locked card prompt requesting consistent history.
  3. **Sidebar Quick Actions:**
     - Selecting a quick action swaps the right sidebar panel dynamically to open specific banking wizards:
       - **Pay Phone:** Enters a 10-digit number and amount to transfer funds.
       - **Transfer:** Initiates standard bank-to-bank transfers.
       - **UPI Pay:** Transfers funds directly to a UPI address (e.g., `arpitha1@siri`).
       - **Limits:** Drag ranges to update Daily ATM and Online limits.
       - **Offers:** View current reward promotions (e.g., cashback on Amazon or fuel).
       - **Loan / Credit Services:** Opens a loan application form.
       - **Scan & Pay:** Simulates scanning a barcode with a sweep-line animation.
       - **Add Money:** Virtual gateway to deposit funds into the account using cards or UPI.
       - **Autopay (Standing Instructions):** Schedule bills (Airtel, Tata Play, BESCOM).
  4. **Activity Tabs:**
     - **Recent Activity:** Displays the latest transactions in real-time.
     - **Upcoming Activity:** Lists scheduled recurring transfers.

---

### C. ATM Services Module
* **Location:** `/atm-services`
* **Features:**
  - **Segmented Control:** Toggle switch between Debit Card and Credit Card profiles.
  - **Card Details Unmasking:** Clicking "View Details" decrypts CVV and Expiry fields and displays the card numbers on screen.
  - **Instant Blocking:** Clicking "Block Card" triggers a verification modal. If confirmed, the card visual applies a grayscale filter, a red `BLOCKED` stamp, and disables further operations.
  - **Reset PIN:** A modal to update the card's 4-digit security code.
  - **New Card Application:** Custom order form choosing card networks (Visa, Mastercard, RuPay), card tier, and shipping addresses. Submitting pushes a request into the admin queue.

---

### D. Aadhaar KYC Linking Wizard
* **Location:** `/aadhaar-kyc`
* **Features:**
  - Follows a strict **4-Step Verification Wizard**:
    1. **Details:** Input full legal name, Date of Birth, and 12-digit Aadhaar number.
    2. **OTP Verification:** Simulate a 6-digit one-time password security check.
    3. **Face Liveness Check:** Simulates biometrics. Clicking start triggers a radar sweep line across a face placeholder, prompting instructions: *"Blink your eyes..."* -> *"Turn your head left..."* -> *"Almost done..."* before completing.
    4. **Confirmation:** Sends verification logs to the database queue and updates the page with a success summary.
  - Once verified, the page automatically switches to a static dashboard showing "KYC Verified" or "Pending Audit".

---

### E. AI Chatbot Assistant & Voice Search
* **Location:** Floating circular widget in the bottom-right corner of the interface.
* **Features:**
  - **Intent Parsing:** Powered by regular expression matching in `chatbot_logic.py` that processes intents:
    - **Greetings:** Responds with a polite intro.
    - **Balance Checks:** Fetches active balances and formats them dynamically.
    - **KYC & ATM Card Requests:** Triggers backend writes to create formal service tickets.
    - **Safety Advice / Guide:** Explains security tips.
  - **Multi-Lingual Support:** Select a language from the dropdown menu (English, Hindi, Kannada) and the bot responds in that language.
  - **Voice Commands:** Includes a microphone toggle. It binds to the Web Speech API (`webkitSpeechRecognition`) to convert user spoken words to chatbot input text hands-free.

---

## 4. Admin Portal walkthrough & Operations

The Admin Portal acts as a bank teller window, compliance office, and back-office center. 

### A. Dashboard Overview & Analytics
* **KPI Metrics:** Displays total active bank clients, outstanding service requests, and live database health metrics.
* **Graphical Charts (Chart.js):**
  - **Transaction Breakdown:** A pie chart detailing deposits, withdrawals, and peer-to-peer transfers.
  - **7-Day Market Volume:** A line graph displaying cumulative transaction volumes over the last 7 days.
* **End of Day (EOD) Cron Run:** Admins can trigger the cron runner manually. It executes all scheduled standing instructions, transfers money between savings accounts, and updates execution history logs.

### B. Aadhaar KYC Approval Queue
* Shows a list of submitted customer Aadhaar data.
* Admins can click **Approve** or **Reject**. Approving changes the status to verified, unlocking high-tier actions for the user.

### C. Credit Underwriting (Loans)
* Lists submitted loan applications (Borrower, Amount, Purpose).
* **Loan Disbursement Flow:** When an admin clicks **Approve**, the system:
  1. Updates the loan table to `APPROVED`.
  2. Directly adds the approved loan amount to the customer's savings account balance.
  3. Records a ledger transaction with the tag `LOAN DISBURSEMENT` for audit trails.

### D. Card Issuance Queue
* Reviews requests for replacement cards (Network, Variant, Shipping address).
* Approving completes the request, registering a card creation log.

### E. Customer Directory
* Lists all registered users with their account numbers, phone numbers, and balances.
* Admins can click any customer row to pull up a full profile audit showing recent transaction histories and request lists.

### F. Branch Teller Terminal
* Simulates physical cashier operations (Cash Deposit / Cash Withdrawal).
* A teller inputs the customer's account number, IFSC code, amount, and transaction narration.
* The system performs safety checks (e.g., overdraft prevention) and issues a transaction reference ID upon success.

---

## 5. Typical Student Scenario Demonstrations

To demo the project's features in a presentation, run through these sequences:

### Scenario 1: Peer-to-Peer Transfer Flow
1. Log in as **Arpitha** (`CUST1001` / `password123`) using the fingerprint toggle.
2. Under **Quick Actions**, click **Transfer**.
3. Input a peer account (e.g., `ACC80001` - Chaithanya) and transfer `₹1,000`.
4. Go to **Request History** to see the transaction ledger entry immediately logged, showing the deducted amount.
5. Log out and log back in as Admin (`ADMIN001` / `admin123`). Go to the **Customer Directory** to confirm Chaithanya's account balance has increased by `₹1,000`.

### Scenario 2: KYC & Card Application Flow
1. Log in as a customer. Navigate to **Aadhaar/KYC** in the sidebar.
2. Complete the multi-step verification wizard including the simulated face scan.
3. Next, navigate to **ATM Services**, click **Apply Now** on the right sidebar, select a Visa Platinum card, and submit.
4. Log out and enter the Admin Portal.
5. Go to **KYC Approvals** -> click **Approve** on the customer's request.
6. Go to **Card Issuance** -> click **Approve** on the card request.
7. Log back in as the customer; they will now see their KYC status as fully approved.

### Scenario 3: Voice Chatbot Interaction
1. Log in as a customer. Click the floating chat bubble to open the assistant.
2. Click the **Microphone** icon (allow browser mic permissions) and speak: *"Show my balance"*.
3. The chatbot will translate the spoken words, recognize the balance inquiry intent, query the SQLite database, and speak/respond with the balance details.
4. Select "हिंदी (Hindi)" from the topbar language dropdown. Speak or type *"मदद"* (help). The bot will respond with safety guidelines translated into Hindi.
