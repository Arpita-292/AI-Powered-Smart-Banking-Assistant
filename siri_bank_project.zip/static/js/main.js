// Initialization on Load
// Inject shared components immediately (skip on profile page)
if (window.location.pathname !== '/profile') {
    injectProfileModal();
}

document.addEventListener('DOMContentLoaded', () => {
    loadUserSummary();

    // Auto-scroll chat to bottom
    const chatBox = document.getElementById('chat-messages');
    if (chatBox) chatBox.scrollTop = chatBox.scrollHeight;
});

// Logout function
async function logout() {
    try {
        await fetch('/api/logout', { method: 'POST' });
        window.location.href = '/';
    } catch (e) {
        console.error(e);
    }
}

// Fetch dashboard data
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

async function loadUserSummary() {
    try {
        const response = await fetch('/api/user/summary');
        if (response.ok) {
            const data = await response.json();
            currentUserData = data;

            // Update Balance Card
            if (data.accounts && data.accounts.length > 0) {
                const acc = data.accounts[0];
                const bEl = document.getElementById('main-balance');
                if (bEl) {
                    const formattedBalance = `₹${parseFloat(acc.balance).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
                    bEl.setAttribute('data-balance', formattedBalance);
                    // Check if it should be hidden
                    if (sessionStorage.getItem('balanceHidden') === 'true') {
                        bEl.innerText = '₹ ••••••';
                        const eyeIcon = document.getElementById('balance-eye-icon');
                        if (eyeIcon) eyeIcon.className = 'fa-solid fa-eye-slash';
                    } else {
                        bEl.innerText = formattedBalance;
                    }
                }
                const aEl = document.getElementById('main-account-number');
                if (aEl) aEl.innerText = `Acc: ••••${acc.account_number.slice(-4)}`;
                
                // Update UPI ID
                const uEl = document.getElementById('main-upi-id');
                if (uEl) uEl.innerText = `UPI ID: ${data.user.upi_id || 'Not set'}`;
            }

            // Update Recent Activity List (Redesigned)
            const recentList = document.getElementById('recent-activity-list');
            if (recentList) {
                recentList.innerHTML = '';
                if (data.transactions && data.transactions.length > 0) {
                    data.transactions.forEach(tx => {
                        const dateObj = new Date(tx.created_at);
                        const dateStr = dateObj.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
                        
                        // Fix: Correctly identify if it's a credit or debit for THIS user
                        let isCredit = tx.transaction_type === 'DEPOSIT';
                        if (tx.transaction_type === 'TRANSFER') {
                            isCredit = (tx.receiver_id === data.user.id);
                        }
                        
                        let icon = '<i class="fa-solid fa-arrow-right-from-bracket"></i>';
                        let iconBg = '#fee2e2';
                        let iconColor = '#ef4444';
                        
                        if(isCredit) {
                            icon = '<i class="fa-solid fa-arrow-left-long"></i>';
                            iconBg = '#d1fae5';
                            iconColor = '#10b981';
                        } else if(tx.transaction_type === 'TRANSFER' || tx.transaction_type === 'WITHDRAWAL') {
                            icon = tx.transaction_type === 'TRANSFER' ? '<i class="fa-solid fa-paper-plane"></i>' : '<i class="fa-solid fa-money-bill-transfer"></i>';
                            iconBg = tx.transaction_type === 'TRANSFER' ? '#e0e7ff' : '#fff7ed';
                            iconColor = tx.transaction_type === 'TRANSFER' ? '#6366f1' : '#f97316';
                        }

                        const onclickAction = (!isCredit && tx.transaction_type === 'TRANSFER' && tx.receiver_account) 
                            ? `onclick="prefillSidebarBankTransfer('${tx.receiver_account}')" style="cursor:pointer;"`
                            : '';

                        recentList.innerHTML += `
                            <div class="activity-item" ${onclickAction}>
                                <div class="activity-info">
                                    <div class="activity-icon" style="background: ${iconBg}; color: ${iconColor};">
                                        ${icon}
                                    </div>
                                    <div class="activity-details">
                                        <div style="font-weight: 600; color: var(--text-dark); display:flex; align-items:center; gap:5px;">
                                            ${isCredit ? (tx.sender_name ? 'From ' + tx.sender_name : tx.description) : (tx.receiver_name ? 'To ' + tx.receiver_name : tx.description)}
                                            ${(!isCredit && tx.transaction_type === 'TRANSFER') ? '<i class="fa-solid fa-rotate-left" style="font-size:0.7rem; color:var(--primary-color);" title="Pay Again"></i>' : ''}
                                        </div>
                                        <div style="font-size: 0.75rem;">${dateStr} &bull; TXN-${tx.id} &bull; ${tx.transaction_type}</div>
                                    </div>
                                </div>
                                <div class="activity-amount ${isCredit ? 'credit' : 'debit'}">
                                    ${isCredit ? '+' : '-'} ₹${parseFloat(tx.amount).toLocaleString('en-IN')}
                                </div>
                            </div>
                        `;
                    });
                } else {
                    recentList.innerHTML = '<div style="text-align:center; padding: 20px; color: #94a3b8;">No recent transactions.</div>';
                }
            }
        }
        loadUpcomingActivity();
        loadSuggestedPayees();
    } catch (e) {
        console.error("Dashboard fetch error:", e);
    }
}

async function executeQuickTransfer() {
    const acc = document.getElementById('transfer-acc').value;
    const amt = document.getElementById('transfer-amt').value;
    const isRecurring = document.getElementById('is-recurring').checked;
    const day = document.getElementById('recur-day').value;

    try {
        let endpoint = '/api/transfer';
        let body = { receiver_account: acc, amount: amt };
        
        if (isRecurring) {
            endpoint = '/api/standing_instruction';
            body.day_of_month = day;
        }

        const res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const data = await res.json();
        showToast(data.message);
        if (data.success) {
            document.getElementById('quick-transfer-form').reset();
            loadUserSummary();
        }
    } catch (e) {
        showToast("Transfer failed");
    }
}

async function applyLoan() {
    const btn = document.getElementById('loan-submit-btn');
    const oldText = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    
    const amt = document.getElementById('loan-amt').value;
    const purpose = document.getElementById('loan-purpose').value;

    try {
        const res = await fetch('/api/user/loan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ amount: amt, purpose: purpose })
        });
        const data = await res.json();
        alert(data.message);
        btn.innerHTML = oldText;
        if (data.success) document.getElementById('loan-form').reset();
    } catch (e) {
        alert("Loan application failed");
        btn.innerHTML = oldText;
    }
}

async function loadSuggestedPayees() {
    const list = document.getElementById('suggested-users-list');
    const sideList = document.getElementById('sidebar-recent-payees');
    const sideListAlt = document.getElementById('sidebar-recent-payees-alt');
    
    if (!list && !sideList && !sideListAlt) return;
    
    try {
        const res = await fetch('/api/user/payees');
        const data = await res.json();
        allPayees = data;
        
        if (list) list.innerHTML = '';
        if (sideList) sideList.innerHTML = '';
        if (sideListAlt) sideListAlt.innerHTML = '';
        
        if (data && data.length > 0) {
            data.forEach(user => {
                const initial = user.full_name.charAt(0);
                const html = `
                    <div class="user-circle-item" onclick="prefillSidebarPay('${user.phone_number}')" style="min-width: 65px;">
                        <div class="user-avatar" style="width: 45px; height: 45px; font-size: 1rem;">${initial}</div>
                        <div class="user-circle-name" style="font-size: 0.7rem;">${user.full_name.split(' ')[0]}</div>
                    </div>
                `;
                if (list) list.innerHTML += html;
                if (sideList) sideList.innerHTML += html;
                if (sideListAlt) sideListAlt.innerHTML += html;
            });
        } else {
            const emptyMsg = '<div style="color: #94a3b8; font-size: 0.8rem;">No recent payees</div>';
            if (list) list.innerHTML = emptyMsg;
            if (sideList) sideList.innerHTML = emptyMsg;
            if (sideListAlt) sideListAlt.innerHTML = emptyMsg;
        }
    } catch (e) {
        console.error("Error loading payees:", e);
    }
}

function prefillSidebarPay(phone) {
    showSidebarAction('pay-phone');
    const input = document.getElementById('side-pay-phone');
    if (input) {
        input.value = phone;
        document.getElementById('side-pay-amt').focus();
    }
}

function prefillSidebarBankTransfer(acc) {
    showSidebarAction('bank-transfer');
    const input = document.getElementById('side-bank-acc');
    if (input) {
        input.value = acc;
        document.getElementById('side-bank-amt').focus();
    }
}

let allPayees = []; // Cache for searching

async function searchPayees() {
    const query = document.getElementById('payee-search-input').value.toLowerCase();
    const list = document.getElementById('suggested-users-list');
    if (!list) return;

    if (allPayees.length === 0) {
        // Load them if not already loaded
        const res = await fetch('/api/user/payees');
        allPayees = await res.json();
    }

    const filtered = allPayees.filter(p => 
        p.full_name.toLowerCase().includes(query) || 
        p.phone_number.includes(query)
    );

    list.innerHTML = '';
    if (filtered.length > 0) {
        filtered.forEach(user => {
            const initial = user.full_name.charAt(0);
            list.innerHTML += `
                <div class="user-circle-item" onclick="prefillSidebarPay('${user.phone_number}')">
                    <div class="user-avatar">${initial}</div>
                    <div class="user-circle-name">${user.full_name.split(' ')[0]}</div>
                </div>
            `;
        });
    } else {
        list.innerHTML = '<div style="color: #94a3b8; font-size: 0.8rem; padding: 10px;">No results found</div>';
    }
}

async function loadUpcomingActivity() {
    const list = document.getElementById('upcoming-activity-list');
    if (!list) return;
    try {
        const res = await fetch('/api/user/upcoming');
        const data = await res.json();
        list.innerHTML = '';
        if (data && data.length > 0) {
            data.forEach(item => {
                list.innerHTML += `
                    <div class="activity-item">
                        <div class="activity-info">
                            <div class="activity-icon" style="background: #fef3c7; color: #d97706;">
                                <i class="fa-solid fa-clock"></i>
                            </div>
                            <div class="activity-details">
                                <div style="display:flex; align-items:center; gap:8px;">
                                    Recurring Transfer to ${item.receiver_account}
                                    <span class="upcoming-badge">Scheduled</span>
                                </div>
                                <div>Due on Day ${item.day_of_month} of month</div>
                            </div>
                        </div>
                        <div class="activity-amount" style="color: #64748b;">
                            ₹${parseFloat(item.amount).toLocaleString('en-IN')}
                        </div>
                    </div>
                `;
            });
        } else {
            list.innerHTML = '<div style="text-align:center; padding: 20px; color: #94a3b8;">No upcoming activities scheduled.</div>';
        }
    } catch (e) {
        console.error("Error loading upcoming:", e);
    }
}

function toggleBalanceVisibility() {
    const bEl = document.getElementById('main-balance');
    const eye = document.getElementById('balance-eye-icon');
    const isHidden = bEl.innerText.includes('•');
    
    if (isHidden) {
        bEl.innerText = bEl.getAttribute('data-balance');
        eye.className = 'fa-solid fa-eye';
        sessionStorage.setItem('balanceHidden', 'false');
    } else {
        bEl.innerText = '₹ ••••••';
        eye.className = 'fa-solid fa-eye-slash';
        sessionStorage.setItem('balanceHidden', 'true');
    }
}

function switchActivityTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    if (tab === 'recent') {
        document.getElementById('recent-activity-list').style.display = 'flex';
        document.getElementById('upcoming-activity-list').style.display = 'none';
    } else {
        document.getElementById('recent-activity-list').style.display = 'none';
        document.getElementById('upcoming-activity-list').style.display = 'flex';
    }
}

let currentUserData = null;

function showToast(msg) {
    const toast = document.getElementById('toast-msg') || document.getElementById('toast');
    if (!toast) {
        console.log("Toast: " + msg);
        return;
    }
    toast.innerText = msg;
    toast.classList.add('show');
    toast.style.display = 'block';
    setTimeout(() => { 
        toast.classList.remove('show');
        toast.style.display = 'none';
    }, 3000);
}

let profileModalTimeout = null;

async function openProfile() {
    console.log("openProfile() explicitly called. Width:", window.innerWidth);
    let modal = document.getElementById('siri-profile-modal-overlay');
    
    if (!modal) {
        console.log("Modal missing, injecting...");
        injectProfileModal();
        modal = document.getElementById('siri-profile-modal-overlay');
    }
    
    if (!modal) {
        alert("Fatal: Profile system failed to initialize. Please refresh.");
        return;
    }
    
    // Clear any pending close timeout
    if (profileModalTimeout) {
        clearTimeout(profileModalTimeout);
        profileModalTimeout = null;
    }
    
    // Use DIRECT INLINE STYLES to bypass all CSS conflicts
    modal.style.setProperty('display', 'flex', 'important');
    modal.style.setProperty('opacity', '1', 'important');
    modal.style.setProperty('z-index', '2147483647', 'important');
    modal.style.setProperty('visibility', 'visible', 'important');
    modal.style.setProperty('pointer-events', 'auto', 'important');
    
    // Add the class for the inner card transition
    modal.classList.add('show');
    
    console.log("Modal visibility set to flex/1/visible");

    const updateUI = () => {
        if (!currentUserData || !currentUserData.user) return;
        const user = currentUserData.user;
        const account = (currentUserData.accounts && currentUserData.accounts.length > 0) ? currentUserData.accounts[0] : { account_number: 'N/A', balance: 0, status: 'N/A' };
        
        const avatar = modal.querySelector('#prof-avatar');
        const name = modal.querySelector('#prof-name');
        const id = modal.querySelector('#prof-id');
        const upi = modal.querySelector('#prof-upi');
        const acc = modal.querySelector('#prof-acc');
        const balance = modal.querySelector('#prof-balance');
        const status = modal.querySelector('#prof-status');

        if (avatar) avatar.innerText = (user.full_name || "?")[0].toUpperCase();
        if (name) name.innerText = user.full_name || "User";
        if (id) id.innerText = user.customer_id || "N/A";
        if (upi) upi.innerText = (user.upi_id ? user.upi_id + "@siribank" : "Not Set");
        if (acc) acc.innerText = account.account_number;
        if (balance) balance.innerText = "₹" + parseFloat(account.balance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 });
        if (status) {
            status.innerText = account.status;
            status.style.color = (account.status === 'ACTIVE' || account.status === 'APPROVED') ? '#10b981' : '#ef4444';
        }
    };

    // If we have data, show it immediately
    if (currentUserData) {
        updateUI();
    } else {
        // Show loading in modal if no data yet
        const balance = modal.querySelector('#prof-balance');
        if (balance) balance.innerText = "Loading...";
    }

    // Refresh data in background
    try {
        await loadUserSummary();
        updateUI();
    } catch (e) {
        console.error("Failed to refresh profile data:", e);
        if (!currentUserData) {
            const balance = modal.querySelector('#prof-balance');
            if (balance) balance.innerText = "Error loading";
        }
    }
}

function closeProfile() {
    const modal = document.getElementById('siri-profile-modal-overlay');
    if (modal) {
        modal.classList.remove('show');
        if (profileModalTimeout) clearTimeout(profileModalTimeout);
        profileModalTimeout = setTimeout(() => {
            if (!modal.classList.contains('show')) {
                modal.style.setProperty('display', 'none', 'important');
                modal.style.setProperty('opacity', '0', 'important');
            }
            profileModalTimeout = null;
        }, 300);
    }
}

window.openProfile = openProfile;
window.closeProfile = closeProfile;

function injectProfileModal() {
    console.log("Checking profile modal injection...");
    if (document.getElementById('siri-profile-modal-overlay')) return;
    
    const modalHtml = `
    <div id="siri-profile-modal-overlay" class="siri-profile-modal-overlay" onclick="if(event.target === this) closeProfile()">
        <div class="profile-card-modal">
            <div class="profile-header">
                <button class="close-modal" onclick="closeProfile()"><i class="fa-solid fa-xmark"></i></button>
                <div class="profile-avatar" id="prof-avatar">?</div>
                <h2 id="prof-name" style="margin: 0; font-weight: 800;">User</h2>
                <p style="opacity: 0.8; font-size: 0.9rem; margin-top: 5px;" id="prof-upi">@siribank</p>
            </div>
            <div class="profile-body">
                <div class="profile-detail-group">
                    <div class="detail-row">
                        <span class="detail-label">Customer ID</span>
                        <span class="detail-value" id="prof-id">Loading...</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Account Number</span>
                        <span class="detail-value" id="prof-acc">Loading...</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">IFSC Code</span>
                        <span class="detail-value">SIRI0004829</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Branch</span>
                        <span class="detail-value">MAIN BRANCH (AI)</span>
                    </div>
                </div>

                <div class="profile-detail-group" style="background: #f1f5f9; padding: 15px; border-radius: 12px;">
                    <div class="detail-row" style="border: none; padding: 0;">
                        <span class="detail-label">Current Ledger Balance</span>
                        <span class="detail-value" style="color: var(--primary-color); font-size: 1.1rem;" id="prof-balance">₹--</span>
                    </div>
                    <div class="detail-row" style="border: none; padding: 5px 0 0 0;">
                        <span class="detail-label">Account Status</span>
                        <span class="detail-value" id="prof-status" style="color: #10b981; text-transform: uppercase; font-size: 0.75rem; background: #d1fae5; padding: 2px 8px; border-radius: 50px;">ACTIVE</span>
                    </div>
                </div>
            </div>
            <div class="profile-footer">
                <button class="btn-primary" onclick="location.href='/aadhaar-kyc'" style="width: 100%; justify-content: center;">
                    <i class="fa-solid fa-id-card" style="margin-right: 8px;"></i> View KYC Details
                </button>
            </div>
        </div>
    </div>`;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
}

async function executeQuickTransfer() {
    const acc = document.getElementById('transfer-acc').value;
    const amt = document.getElementById('transfer-amt').value;
    const isRecurring = document.getElementById('is-recurring') ? document.getElementById('is-recurring').checked : false;
    const recurDay = document.getElementById('recur-day') ? document.getElementById('recur-day').value : 1;

    if (!acc || !amt) return;

    // UI Loading state
    const btn = document.querySelector('.transfer-form button');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;

    try {
        let endpoint = isRecurring ? '/api/standing_instruction' : '/api/transfer';
        let payload = { receiver_account: acc, amount: amt };
        if (isRecurring) payload.day_of_month = recurDay;

        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await response.json();

        if (data.success) {
            showToast(isRecurring ? "Standing Instruction Saved!" : "Transfer Successful to " + acc);
            document.getElementById('quick-transfer-form').reset();
            if (document.getElementById('recur-day-group')) document.getElementById('recur-day-group').style.display = 'none';
            loadUserSummary(); // reload balances and history
        } else {
            alert("Failed: " + data.message);
        }
    } catch (e) {
        alert("Network error processing request");
    } finally {
        btn.innerHTML = isRecurring ? 'Initialize Instruction' : 'Send Money';
        btn.disabled = false;
    }
}

/** CHATBOT LOGIC **/
const chatMessages = document.getElementById('chat-messages');
const chatInput = document.getElementById('chat-input');
const languageSelect = document.getElementById('language-selector');

function appendMessage(text, sender) {
    const msgDiv = document.createElement('div');
    msgDiv.classList.add('message', sender);
    
    // Add text content
    const textSpan = document.createElement('span');
    textSpan.innerText = text;
    msgDiv.appendChild(textSpan);
    
    // Add replay button for bot
    if (sender === 'bot') {
        const replayBtn = document.createElement('button');
        replayBtn.innerHTML = '<i class="fa-solid fa-volume-high"></i>';
        replayBtn.className = 'replay-voice-btn';
        replayBtn.onclick = () => speakText(text);
        msgDiv.appendChild(replayBtn);
    }
    
    chatMessages.appendChild(msgDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight; // Auto-scroll
    
    if (sender === 'bot') {
        speakText(text);
    }
}

/** TTS (Text to Speech) Logic **/
function speakText(text) {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    const lang = languageSelect.value;
    
    const langMap = {
        'English': 'en-IN',
        'Hindi': 'hi-IN',
        'Kannada': 'kn-IN'
    };
    
    const targetLang = langMap[lang] || 'en-US';
    utterance.lang = targetLang;
    
    let voices = window.speechSynthesis.getVoices();
    
    // If voices aren't loaded yet, try again in a bit
    if (voices.length === 0) {
        // Some browsers need a "kick" to start loading voices
        window.speechSynthesis.getVoices(); 
        setTimeout(() => speakText(text), 250);
        return;
    }

    // Advanced Voice Searching logic for "Natural" feel
    let selectedVoice = null;
    
    // 1. Try for Online High Quality (Neural/Online)
    selectedVoice = voices.find(v => v.lang.includes(targetLang) && (v.name.includes('Online') || v.name.includes('Neural')));
    
    // 2. Try for Local High Quality (Natural/Google)
    if (!selectedVoice) {
        selectedVoice = voices.find(v => v.lang.includes(targetLang) && (v.name.includes('Google') || v.name.includes('Natural')));
    }

    // 3. English specific better fallbacks (Avoid David if possible)
    if (!selectedVoice && lang === 'English') {
        selectedVoice = voices.find(v => v.name.includes('Zira')) || 
                        voices.find(v => v.name.includes('Mark')) ||
                        voices.find(v => v.name.includes('Heera'));
    }
    
    // 4. Fallback to any for that language
    if (!selectedVoice) {
        selectedVoice = voices.find(v => v.lang.startsWith(targetLang.split('-')[0]));
    }

    if (selectedVoice) {
        utterance.voice = selectedVoice;
        console.log("Selected Voice:", selectedVoice.name);
    } else {
        console.warn("No specific voice found for", targetLang);
        // If it's Kannada and missing, alert the user once
        if (lang === 'Kannada' && !sessionStorage.getItem('kn_voice_alert')) {
            appendMessage("⚠️ Kannada voice is not installed on this device. [Click here for help](https://support.google.com/chrome/answer/95414)", 'bot-system');
            sessionStorage.setItem('kn_voice_alert', 'true');
        }
    }

    // Voice tuning for human feel
    if (lang === 'English') {
        utterance.rate = 0.95; // Slightly slower is less robotic
        utterance.pitch = 1.05; // Slightly higher pitch feels more friendly
    } else {
        utterance.rate = 0.85; // Regional languages need more clarity
        utterance.pitch = 1.0;
    }
    
    window.speechSynthesis.speak(utterance);
}

async function sendMessage() {
    const text = chatInput.value.trim();
    if (!text) return;

    // Show user message
    appendMessage(text, 'user');
    chatInput.value = '';

    // Simulate typing delay naturally
    setTimeout(async () => {
        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: text,
                    language: languageSelect.value
                })
            });
            const data = await response.json();

            if (data.reply) {
                appendMessage(data.reply, 'bot');
            } else {
                appendMessage("System error. Please try again.", 'bot');
            }

            // If action was executed, refresh the dashboard automatically
            if (data.intent === 'ATM_CARD_REQUEST' || data.intent === 'AADHAAR_LINK_REQUEST') {
                loadUserSummary(); // Reloads table to show 'PENDING'
            }

        } catch (e) {
            console.error("Chat fetch error:", e);
            appendMessage("Offline. Cannot connect to SIRI BANK.", 'bot');
        }
    }, 500);
}

/** VOICE RECOGNITION (Web Speech API) **/
const micBtn = document.getElementById('mic-btn');
let isRecording = false;
let recognition = null;

if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onresult = function (event) {
        const transcript = event.results[0][0].transcript;
        chatInput.value = transcript;
        sendMessage(); // instantly send the voice match
    };

    recognition.onerror = function (event) {
        console.error('Speech recognition error', event.error);
        stopVoice();
    };

    recognition.onend = function () {
        stopVoice();
    };
} else {
    console.warn("Speech Recognition API not supported in this browser.");
}

function toggleVoice() {
    if (!recognition) {
        alert("Voice recognition is not supported in this browser.");
        return;
    }

    if (isRecording) {
        stopVoice();
    } else {
        startVoice();
    }
}

function toggleChat() {
    const chatContainer = document.getElementById('chat-container');
    const toggleBtnIcon = document.querySelector('#chat-toggle-btn i');

    chatContainer.classList.toggle('open');
    if (chatContainer.classList.contains('open')) {
        toggleBtnIcon.classList.remove('fa-comment-dots');
        toggleBtnIcon.classList.add('fa-times');
        document.getElementById('chat-input').focus();
    } else {
        toggleBtnIcon.classList.add('fa-comment-dots');
        toggleBtnIcon.classList.remove('fa-times');
    }
}

function startVoice() {
    // Set recognition language based on dropdown
    const lang = languageSelect.value;
    if (lang === 'Hindi') recognition.lang = 'hi-IN';
    else if (lang === 'Kannada') recognition.lang = 'kn-IN';
    else recognition.lang = 'en-US';

    try {
        recognition.start();
        micBtn.classList.remove('idle-pulse');
        micBtn.classList.add('mic-active');
        isRecording = true;
        chatInput.placeholder = "Listening...";
    } catch (e) {
        console.error(e);
    }
}

function stopVoice() {
    try {
        recognition.stop();
    } catch (e) { }
    micBtn.classList.remove('mic-active');
    micBtn.classList.add('idle-pulse');
    isRecording = false;
    chatInput.placeholder = "Type a message or use voice...";
}

/** PAYMENT MODAL LOGIC **/
function openPayModal(type, data = {}) {
    const overlay = document.getElementById('payment-modal-overlay');
    const title = document.getElementById('modal-title');
    const phoneInput = document.getElementById('pay-phone-number');
    const amountInput = document.getElementById('pay-amount');
    
    if (type === 'phone') {
        title.innerText = 'Pay to Phone Number';
        phoneInput.placeholder = 'Enter 10-digit mobile number';
        if (data.phone) phoneInput.value = data.phone;
    }
    
    overlay.style.display = 'flex';
    phoneInput.focus();
}

function closePayModal() {
    document.getElementById('payment-modal-overlay').style.display = 'none';
    document.getElementById('pay-phone-form').reset();
}

async function executePhoneTransfer() {
    const phone = document.getElementById('pay-phone-number').value;
    const amount = document.getElementById('pay-amount').value;
    const btn = document.getElementById('confirm-payment-btn');
    
    if (!phone || !amount) {
        showToast("Please enter both phone number and amount");
        return;
    }
    
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;
    
    try {
        const response = await fetch('/api/transfer/phone', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone_number: phone, amount: amount })
        });
        const data = await response.json();
        
        if (data.success) {
            showToast(`Sent ₹${amount} to ${data.receiver_name}`);
            closePayModal();
            loadUserSummary(); // Refresh dashboard
        } else {
            showToast(data.message);
        }
    } catch (e) {
        showToast("Network error. Try again.");
    } finally {
        btn.innerHTML = 'Confirm Payment';
        btn.disabled = false;
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const overlays = document.querySelectorAll('.modal-overlay');
    overlays.forEach(overlay => {
        if (event.target == overlay) {
            overlay.style.display = 'none';
        }
    });
}

/** GENERIC MODAL LOGIC **/
function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.style.display = 'flex';
}

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) modal.style.display = 'none';
}

/** SIDEBAR ACTION LOGIC **/
function showSidebarAction(type) {
    const defaultContent = document.getElementById('default-sidebar-content');
    const dynamicContent = document.getElementById('dynamic-action-content');
    const tools = document.querySelectorAll('.sidebar-tool');
    
    if (!defaultContent || !dynamicContent) return;
    
    // Hide default, show dynamic
    defaultContent.style.display = 'none';
    dynamicContent.style.display = 'block';
    
    // Hide all tools, show selected one
    tools.forEach(tool => tool.style.display = 'none');
    const selectedTool = document.getElementById(`sidebar-${type}`);
    if (selectedTool) selectedTool.style.display = 'block';
    
    // Scroll sidebar to top
    document.getElementById('right-sidebar-panel').scrollTop = 0;
}

function resetSidebar() {
    const defaultContent = document.getElementById('default-sidebar-content');
    const dynamicContent = document.getElementById('dynamic-action-content');
    
    if (!defaultContent || !dynamicContent) return;
    
    defaultContent.style.display = 'block';
    dynamicContent.style.display = 'none';
}

async function executeSidebarPhoneTransfer() {
    const phone = document.getElementById('side-pay-phone').value;
    const amount = document.getElementById('side-pay-amt').value;
    const btn = document.getElementById('side-confirm-pay');
    
    if (!phone || !amount) {
        showToast("Please enter both phone number and amount");
        return;
    }
    
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;
    
    try {
        const response = await fetch('/api/transfer/phone', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone_number: phone, amount: amount })
        });
        const data = await response.json();
        
        if (data.success) {
            showToast(`Sent ₹${amount} to ${data.receiver_name}`);
            resetSidebar();
            loadUserSummary();
        } else {
            showToast(data.message);
        }
    } catch (e) {
        showToast("Network error. Try again.");
    } finally {
        btn.innerHTML = 'Confirm Payment';
        btn.disabled = false;
    }
}

/** QUICK ACTIONS LOGIC (Updated for Sidebar) **/
async function executeAddMoney() {
    const amount = document.getElementById('side-add-amt').value;
    if (!amount) {
        showToast("Please enter an amount");
        return;
    }
    
    const btn = document.querySelector('#sidebar-add-money .btn-primary');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    
    setTimeout(() => {
        showToast(`₹${amount} added to your account successfully!`);
        resetSidebar();
        loadUserSummary();
        btn.innerHTML = 'Add Money';
    }, 1500);
}

function processScan() {
    const btn = document.querySelector('#sidebar-scan-pay .btn-primary');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Scanning...';
    
    setTimeout(() => {
        showToast("QR Scanned: Merchant 'SIRI COFFEE'.");
        btn.innerHTML = 'Scan QR Code';
        showSidebarAction('pay-phone'); // Switch to payment tool
    }, 2000);
}

async function applyInstantLoan() {
    const amount = document.getElementById('side-loan-amt').value;
    const emp = document.getElementById('side-loan-emp').value;
    const income = document.getElementById('side-loan-income').value;
    const tenure = document.getElementById('side-loan-tenure').value;
    const btn = document.querySelector('#sidebar-instant-loan .btn-primary');
    
    if (!amount || !income) {
        showToast("Please enter all details including income");
        return;
    }
    
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Verifying Credit...';
    btn.disabled = true;

    try {
        const response = await fetch('/api/user/loan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                amount: amount, 
                purpose: `Instant Loan - ${emp} (${tenure}m) | Monthly Income: ₹${income}` 
            })
        });
        const data = await response.json();
        
        if (data.success) {
            showToast("Application Submitted for Underwriting!");
            resetSidebar();
            loadUserSummary();
        } else {
            showToast(data.message);
        }
    } catch (e) {
        showToast("Network Error. Try again.");
    } finally {
        btn.innerHTML = 'Submit Application';
        btn.disabled = false;
    }
}

async function executeSidebarBankTransfer() {
    const acc = document.getElementById('side-bank-acc').value;
    const amount = document.getElementById('side-bank-amt').value;
    const btn = document.getElementById('side-confirm-bank');
    
    if (!acc || !amount) {
        showToast("Please enter account number and amount");
        return;
    }
    
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;
    
    // Mock bank transfer API call
    setTimeout(() => {
        showToast(`₹${amount} transferred to ${acc} successfully!`);
        resetSidebar();
        loadUserSummary();
        btn.innerHTML = 'Send Money';
        btn.disabled = false;
    }, 1500);
}

async function executeSidebarUPITransfer() {
    const upiId = document.getElementById('side-upi-id').value;
    const amount = document.getElementById('side-upi-amt').value;
    const btn = document.getElementById('side-confirm-upi');
    
    if (!upiId || !amount) {
        showToast("Please enter UPI ID and amount");
        return;
    }
    
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;
    
    // Mock UPI transfer API call
    setTimeout(() => {
        showToast(`₹${amount} paid to ${upiId} successfully!`);
        resetSidebar();
        loadUserSummary();
        btn.innerHTML = 'Pay UPI ID';
        btn.disabled = false;
    }, 1500);
}
