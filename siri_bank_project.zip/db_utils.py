import sqlite3
import os
import random

DB_NAME = os.path.join(os.path.dirname(__file__), 'siri_bank.db')

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # Create tables with is_admin field
    cursor.executescript('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id VARCHAR(20) UNIQUE NOT NULL,
        phone_number VARCHAR(15) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        preferred_language VARCHAR(20) DEFAULT 'English',
        upi_id VARCHAR(50) UNIQUE,
        is_admin BOOLEAN DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        account_number VARCHAR(20) UNIQUE NOT NULL,
        balance DECIMAL(15, 2) DEFAULT 0.00,
        status VARCHAR(20) DEFAULT 'ACTIVE',
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        request_type VARCHAR(50) NOT NULL,
        request_details TEXT,
        status VARCHAR(20) DEFAULT 'PENDING',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER,
        receiver_id INTEGER,
        amount DECIMAL(15, 2) NOT NULL,
        transaction_type VARCHAR(20) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS loans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount DECIMAL(15, 2) NOT NULL,
        purpose TEXT,
        status VARCHAR(20) DEFAULT 'PENDING',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS standing_instructions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        receiver_account VARCHAR(20) NOT NULL,
        amount DECIMAL(15, 2) NOT NULL,
        day_of_month INTEGER NOT NULL,
        last_executed TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    ''')
    
    # Migration: Check if upi_id exists, add if not
    try:
        cursor.execute("SELECT upi_id FROM users LIMIT 1")
    except sqlite3.OperationalError:
        cursor.execute("ALTER TABLE users ADD COLUMN upi_id VARCHAR(50)")
        # Optionally populate existing users if they have none
        cursor.execute("SELECT id, full_name FROM users")
        users = cursor.fetchall()
        for u in users:
            # u[0] is id, u[1] is full_name
            upi = f"{u[1].split()[0].lower()}{u[0]}@siri"
            cursor.execute("UPDATE users SET upi_id = ? WHERE id = ?", (upi, u[0]))
    
    # Check if dummy data exists
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        # Create Admin
        cursor.execute('''
        INSERT INTO users (customer_id, phone_number, password_hash, full_name, is_admin, upi_id) 
        VALUES ('ADMIN001', '0000000000', 'admin123', 'System Administrator', 1, 'admin@siri')
        ''')
        admin_id = cursor.lastrowid
        
        # Create Dummy Account for system deposits/withdrawals tracking (optional, using admin ID)
        cursor.execute('''
        INSERT INTO accounts (user_id, account_number, balance, status)
        VALUES (?, 'SYSTEM000', 999999999.00, 'ACTIVE')
        ''', (admin_id,))
        
        # Create 4 dummy users
        names = ["Arpitha", "Chaithanya", "Harshitha", "Jyothi"]
                 
        for i in range(4):
            customer_id = f"CUST100{i+1}"
            phone = f"987654321{i}"
            name = names[i]
            upi = f"{name.split()[0].lower()}{i+1}@siri"
            # insert user
            cursor.execute('''
            INSERT INTO users (customer_id, phone_number, password_hash, full_name, preferred_language, upi_id)
            VALUES (?, ?, 'password123', ?, 'English', ?)
            ''', (customer_id, phone, name, upi))
            user_id = cursor.lastrowid
            
            # insert account
            acc_num = f"ACC{80000 + i}"
            balance = round(random.uniform(5000, 150000), 2)
            cursor.execute('''
            INSERT INTO accounts (user_id, account_number, balance, status)
            VALUES (?, ?, ?, 'ACTIVE')
            ''', (user_id, acc_num, balance))
            pass
        
    conn.commit()
    conn.close()

init_db()

def get_db_connection():
    try:
        conn = sqlite3.connect(DB_NAME)
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as err:
        print(f"Error connecting to DB: {err}")
        return None

def authenticate_user(identifier, password):
    conn = get_db_connection()
    if not conn:
        return None, "Database error"
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, customer_id, full_name, preferred_language, phone_number, is_admin
        FROM users 
        WHERE (phone_number = ? OR customer_id = ?) AND password_hash = ?
    """, (identifier, identifier, password))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    
    if user:
        return dict(user), "Success"
    return None, "Invalid credentials"

def get_user_account_summary(user_id):
    conn = get_db_connection()
    if not conn:
        return None
    cursor = conn.cursor()
    cursor.execute("SELECT account_number, balance, status FROM accounts WHERE user_id = ?", (user_id,))
    accounts = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute("SELECT id, full_name, customer_id, upi_id FROM users WHERE id = ?", (user_id,))
    user_info = dict(cursor.fetchone())

    cursor.execute("SELECT request_type, status, created_at FROM requests WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
    requests = [dict(row) for row in cursor.fetchall()]

    cursor.execute('''
        SELECT 
            t.id, t.amount, t.transaction_type, t.description, t.created_at,
            t.sender_id, t.receiver_id,
            su.full_name as sender_name, ru.full_name as receiver_name
        FROM transactions t
        LEFT JOIN users su ON t.sender_id = su.id
        LEFT JOIN users ru ON t.receiver_id = ru.id
        WHERE t.sender_id = ? OR t.receiver_id = ?
        ORDER BY t.created_at DESC LIMIT 10
    ''', (user_id, user_id))
    transactions = [dict(row) for row in cursor.fetchall()]
    
    cursor.close()
    conn.close()
    return {"accounts": accounts, "recent_requests": requests, "transactions": transactions, "user": user_info}

def execute_transfer(sender_id, receiver_account_num, amount):
    conn = get_db_connection()
    if not conn: return False, "Database error"
    
    receiver_account_num = str(receiver_account_num).strip().upper()
    
    if amount <= 0:
        return False, "Transfer amount must be greater than zero."
        
    try:
        cursor = conn.cursor()
        # 1. Fetch sender account details
        cursor.execute("SELECT id, account_number, balance, status FROM accounts WHERE user_id = ?", (sender_id,))
        sender_acc = cursor.fetchone()
        
        if not sender_acc: return False, "Sender account not found."
        if sender_acc['status'] != 'ACTIVE': return False, f"Sender account is {sender_acc['status'].lower()}."
        if sender_acc['balance'] < amount: return False, "Insufficient funds."
        
        # Edge Case: Prevent sending to self
        if sender_acc['account_number'] == receiver_account_num:
            return False, "Cannot transfer funds to the same account."
            
        # 2. Fetch receiver account details
        cursor.execute("SELECT id, user_id, status FROM accounts WHERE account_number = ?", (receiver_account_num,))
        recv_acc = cursor.fetchone()
        
        if not recv_acc: return False, "Invalid payee account number."
        if recv_acc['status'] != 'ACTIVE': return False, "Receiver account is currently inactive."
        
        # 3. Deduct from sender
        cursor.execute("UPDATE accounts SET balance = balance - ? WHERE id = ?", (amount, sender_acc['id']))
        # 4. Add to receiver
        cursor.execute("UPDATE accounts SET balance = balance + ? WHERE id = ?", (amount, recv_acc['id']))
        
        # 5. Log transaction
        cursor.execute('''
            INSERT INTO transactions (sender_id, receiver_id, amount, transaction_type, description)
            VALUES (?, ?, ?, 'TRANSFER', 'Fund transfer via QuickPay')
        ''', (sender_id, recv_acc['user_id'], amount))
        
        conn.commit()
        return True, "Transfer successful"
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        conn.close()

def create_new_user(full_name, phone, password="password123", initial_deposit=5000.0, preferred_language="English"):
    conn = get_db_connection()
    if not conn: return False, "Database connection error"
    
    phone = str(phone).strip()
    if not phone.isdigit() or len(phone) < 10 or len(phone) > 15:
        return False, "Please enter a valid 10-digit mobile number."
        
    full_name = str(full_name).strip()
    if not full_name:
        return False, "Full name is required."
        
    password = str(password).strip()
    if not password:
        password = "password123"
    
    try:
        cursor = conn.cursor()
        
        # Check if phone number is already registered
        cursor.execute("SELECT id FROM users WHERE phone_number = ?", (phone,))
        if cursor.fetchone():
            return False, "Mobile number already registered. Please sign in instead."
        
        # Generate customer ID and account number
        cursor.execute("SELECT MAX(id) FROM users")
        max_id_row = cursor.fetchone()
        max_id = max_id_row[0] if max_id_row and max_id_row[0] is not None else 0
        next_num = max_id + 1
        
        customer_id = f"CUST10{str(next_num).zfill(2)}"
        first_name = full_name.split()[0].lower() if full_name else "user"
        upi_id = f"{first_name}{next_num}@siri"
        
        cursor.execute('''
            INSERT INTO users (customer_id, phone_number, password_hash, full_name, preferred_language, upi_id, is_admin)
            VALUES (?, ?, ?, ?, ?, ?, 0)
        ''', (customer_id, phone, password, full_name, preferred_language, upi_id))
        
        user_id = cursor.lastrowid
        acc_num = f"ACC{80000 + next_num}"
        
        cursor.execute('''
            INSERT INTO accounts (user_id, account_number, balance, status)
            VALUES (?, ?, ?, 'ACTIVE')
        ''', (user_id, acc_num, initial_deposit))
        
        if initial_deposit > 0:
            cursor.execute('''
            INSERT INTO transactions (receiver_id, amount, transaction_type, description)
            VALUES (?, ?, 'DEPOSIT', 'Welcome Bonus & Account Opening Deposit')
            ''', (user_id, initial_deposit))
            
        conn.commit()
        return True, {
            "user_id": user_id,
            "customer_id": customer_id,
            "account_number": acc_num,
            "full_name": full_name,
            "phone_number": phone,
            "upi_id": upi_id,
            "balance": initial_deposit,
            "preferred_language": preferred_language,
            "is_admin": 0
        }
    except sqlite3.IntegrityError as ie:
        return False, "Phone number or ID already registered."
    except Exception as e:
        return False, str(e)
    finally:
        conn.close()

def admin_execute_financial_op(account_number, ifsc_code, op_type, amount, narration):
    conn = get_db_connection()
    if not conn: return False, "Database error"
    
    account_number = str(account_number).strip().upper()
    ifsc_code = str(ifsc_code).strip().upper()
    
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id, user_id, balance FROM accounts WHERE account_number = ?", (account_number,))
        acc = cursor.fetchone()
        if not acc: return False, "Target Bank Account not found"
        
        user_id = acc['user_id']
        desc = f"Teller {op_type.capitalize()} - {narration} (IFSC: {ifsc_code})"
        
        if op_type == 'withdraw':
            if acc['balance'] < amount: return False, "Insufficient funds"
            cursor.execute("UPDATE accounts SET balance = balance - ? WHERE id = ?", (amount, acc['id']))
            cursor.execute('''
            INSERT INTO transactions (sender_id, amount, transaction_type, description)
            VALUES (?, ?, 'WITHDRAWAL', ?)
            ''', (user_id, amount, desc))
        else: # deposit
            cursor.execute("UPDATE accounts SET balance = balance + ? WHERE id = ?", (amount, acc['id']))
            cursor.execute('''
            INSERT INTO transactions (receiver_id, amount, transaction_type, description)
            VALUES (?, ?, 'DEPOSIT', ?)
            ''', (user_id, amount, desc))
            
        conn.commit()
        # Optionally, fetch insert id for a real receipt
        txn_id = cursor.lastrowid
        return True, {"msg": "Operation successful", "txn_id": f"TXN-{txn_id}", "balance": acc['balance'] + (amount if op_type == 'deposit' else -amount)}
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        conn.close()

def create_bank_request(user_id, request_type, request_details):
    conn = get_db_connection()
    if not conn: return False
    cursor = conn.cursor()
    cursor.execute("INSERT INTO requests (user_id, request_type, request_details, status) VALUES (?, ?, ?, 'PENDING')",
                   (user_id, request_type, request_details))
    conn.commit()
    return cursor.lastrowid > 0

# ADMIN QUERIES
def get_all_users_and_requests():
    conn = get_db_connection()
    if not conn: return []
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT r.id as req_id, u.customer_id, u.full_name, r.request_type, r.request_details, r.status, r.created_at
        FROM requests r
        JOIN users u ON u.id = r.user_id
        ORDER BY r.created_at DESC
    """)
    requests = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute("""
        SELECT u.id, u.customer_id, u.full_name, u.phone_number, u.is_admin, a.account_number, a.balance
        FROM users u
        LEFT JOIN accounts a ON a.user_id = u.id
    """)
    users = [dict(row) for row in cursor.fetchall()]
    
    cursor.close()
    conn.close()
    return {"requests": requests, "users": users}

def get_system_analytics():
    conn = get_db_connection()
    if not conn: return {}
    cursor = conn.cursor()
    
    cursor.execute("SELECT SUM(balance) as total_liquidity FROM accounts WHERE status = 'ACTIVE'")
    liquidity = cursor.fetchone()['total_liquidity']
    if liquidity is None: liquidity = 0
    
    cursor.execute("SELECT transaction_type, COUNT(*) as count, SUM(amount) as total FROM transactions GROUP BY transaction_type")
    tx_stats = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT DATE(created_at) as tx_date, SUM(amount) as daily_volume 
        FROM transactions 
        GROUP BY DATE(created_at) 
        ORDER BY tx_date DESC LIMIT 7
    ''')
    daily_volume = [dict(row) for row in cursor.fetchall()]
    daily_volume.reverse()
    
    cursor.close()
    conn.close()
    return {
        "liquidity": float(liquidity),
        "tx_stats": tx_stats,
        "daily_volume": daily_volume
    }

def update_request_status(request_id, status):
    conn = get_db_connection()
    if not conn: return False
    cursor = conn.cursor()
    cursor.execute("UPDATE requests SET status = ? WHERE id = ?", (status, request_id))
    conn.commit()
    conn.close()
    return True

def apply_for_loan(user_id, amount, purpose):
    conn = get_db_connection()
    if not conn: return False, "Database error"
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO loans (user_id, amount, purpose) VALUES (?, ?, ?)", (user_id, amount, purpose))
        conn.commit()
        return True, "Loan application submitted. Under review."
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        conn.close()

def get_all_loans():
    conn = get_db_connection()
    if not conn: return []
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT l.id, u.customer_id, u.full_name, l.amount, l.purpose, l.status, l.created_at
            FROM loans l
            JOIN users u ON u.id = l.user_id
            ORDER BY l.created_at DESC
        """)
        loans = [dict(row) for row in cursor.fetchall()]
        return loans
    finally:
        conn.close()

def admin_process_loan(loan_id, action):
    conn = get_db_connection()
    if not conn: return False, "Database error"
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM loans WHERE id = ?", (loan_id,))
        loan = cursor.fetchone()
        if not loan or loan['status'] != 'PENDING':
            return False, "Loan not found or already processed"
            
        cursor.execute("UPDATE loans SET status = ? WHERE id = ?", (action, loan_id))
        
        if action == 'APPROVED':
            user_id = loan['user_id']
            amount = loan['amount']
            cursor.execute("SELECT id FROM accounts WHERE user_id = ?", (user_id,))
            acc = cursor.fetchone()
            if acc:
                cursor.execute("UPDATE accounts SET balance = balance + ? WHERE id = ?", (amount, acc['id']))
                cursor.execute("""
                    INSERT INTO transactions (sender_id, receiver_id, amount, transaction_type, description)
                    VALUES (NULL, ?, ?, 'DEPOSIT', 'LOAN DISBURSEMENT - ' || ?)
                """, (user_id, amount, loan['purpose']))
        
        conn.commit()
        return True, f"Loan {action.lower()} successfully"
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        conn.close()

def save_standing_instruction(user_id, receiver_account, amount, day_of_month):
    conn = get_db_connection()
    if not conn: return False, "Database error"
    
    receiver_account = str(receiver_account).strip().upper()
    try:
        amount = float(amount)
        day_of_month = int(day_of_month)
    except Exception: return False, "Invalid input formats"

    if amount <= 0: return False, "Amount must be greater than zero."
    if day_of_month < 1 or day_of_month > 28: return False, "Execution day must be between 1 and 28."
    
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM accounts WHERE account_number = ?", (receiver_account,))
        if not cursor.fetchone(): return False, "Invalid payee account number."
        
        cursor.execute("""
            INSERT INTO standing_instructions (user_id, receiver_account, amount, day_of_month)
            VALUES (?, ?, ?, ?)
        """, (user_id, receiver_account, amount, day_of_month))
        conn.commit()
        return True, "Recurring instruction saved."
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        conn.close()

def execute_all_standing_instructions():
    conn = get_db_connection()
    if not conn: return 0, "Database error"
    
    executed_count = 0
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM standing_instructions")
        instructions = cursor.fetchall()
        
        from datetime import datetime
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        for ins in instructions:
            # We bypass the 'day_of_month' check for demonstration and just execute all of them 
            # to simulate the passage of time accurately for the mock.
            success, msg = execute_transfer(ins['user_id'], ins['receiver_account'], ins['amount'])
            if success:
                cursor.execute("UPDATE standing_instructions SET last_executed = ? WHERE id = ?", (now_str, ins['id']))
                executed_count += 1
                
        conn.commit()
        return executed_count, f"Processed {executed_count} recurring transfers."
    except Exception as e:
        conn.rollback()
        return 0, str(e)
    finally:
        conn.close()

def get_standing_instructions(user_id):
    conn = get_db_connection()
    if not conn: return []
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT si.id, si.receiver_account, si.amount, si.day_of_month, si.last_executed,
                   a.account_number as my_account
            FROM standing_instructions si
            JOIN accounts a ON si.user_id = a.user_id
            WHERE si.user_id = ?
        """, (user_id,))
        return [dict(row) for row in cursor.fetchall()]
    finally:
        conn.close()

def get_suggested_payees(user_id):
    conn = get_db_connection()
    if not conn: return []
    try:
        cursor = conn.cursor()
        # 1. Get real recent payees from transaction history
        cursor.execute("""
            SELECT DISTINCT u.id, u.full_name, u.upi_id, u.phone_number, a.account_number, MAX(t.created_at) as last_paid
            FROM transactions t
            JOIN users u ON t.receiver_id = u.id
            JOIN accounts a ON a.user_id = u.id
            WHERE t.sender_id = ? AND u.id != ? AND u.is_admin = 0
            GROUP BY u.id
            ORDER BY last_paid DESC
            LIMIT 5
        """, (user_id, user_id))
        real_payees = [dict(row) for row in cursor.fetchall()]
        
        # 2. If fewer than 5, fill with other registered users
        if len(real_payees) < 5:
            exclude_ids = [p['id'] for p in real_payees] + [user_id]
            placeholders = ','.join(['?'] * len(exclude_ids))
            cursor.execute(f"""
                SELECT u.id, u.full_name, u.upi_id, u.phone_number, a.account_number
                FROM users u
                JOIN accounts a ON a.user_id = u.id
                WHERE u.id NOT IN ({placeholders}) AND u.is_admin = 0
                LIMIT ?
            """, exclude_ids + [5 - len(real_payees)])
            others = [dict(row) for row in cursor.fetchall()]
            real_payees.extend(others)
            
        return real_payees
    finally:
        conn.close()

def get_user_by_phone(phone_number):
    conn = get_db_connection()
    if not conn: return None
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT u.id, u.full_name, a.account_number 
            FROM users u
            JOIN accounts a ON u.id = a.user_id
            WHERE u.phone_number = ?
        """, (phone_number,))
        row = cursor.fetchone()
        return dict(row) if row else None
    finally:
        conn.close()
